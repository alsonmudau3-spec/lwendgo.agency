export default function DriverRegister() {
  return <div>Driver Register</div>;
}
