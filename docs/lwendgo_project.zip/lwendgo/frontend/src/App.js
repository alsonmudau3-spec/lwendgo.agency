export default function App() {
  return <h1>LwendGo</h1>;
}
