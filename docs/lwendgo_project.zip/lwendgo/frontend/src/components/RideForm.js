export default function RideForm() {
  return <div>Ride Form</div>;
}
